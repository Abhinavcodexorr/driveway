# Cardora Sitemap Kit

Portable sitemap module matching [cardora.ca/sitemap.xml](https://www.cardora.ca/sitemap.xml).

## Folder structure

```
sitemap-kit/
├── README.md
├── lib/                  → copy to your project root as `sitemap/`
├── app-routes/           → copy contents into your `app/` folder
└── examples/
    ├── redirects.ts      → paste into next.config.ts
    └── robots.txt        → paste into public/robots.txt
```

## Quick install (Next.js App Router)

### 1. Copy core files

Copy `sitemap-kit/lib/` → `your-project/sitemap/`

### 2. Copy route handlers

Copy everything from `sitemap-kit/app-routes/` into `your-project/app/`:

| Source | Destination |
|--------|-------------|
| `app-routes/sitemap.xml/route.ts` | `app/sitemap.xml/route.ts` |
| `app-routes/sitemap-posttype-page.xml/route.ts` | `app/sitemap-posttype-page.xml/route.ts` |
| `app-routes/sitemap-posttype-post.2026.xml/route.ts` | `app/sitemap-posttype-post.2026.xml/route.ts` |
| `app-routes/website/sitemap/route.ts` | `app/website/sitemap/route.ts` |
| `app-routes/sitemap.xsl/route.ts` | `app/sitemap.xsl/route.ts` |
| `app-routes/site-map/page.tsx` | `app/site-map/page.tsx` |

### 3. TypeScript path alias

Ensure `tsconfig.json` has:

```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./*"]
    }
  }
}
```

Route files import from `@/sitemap/handlers`.

### 4. Customize URLs

Edit `sitemap/config.ts`:

- `SITEMAP_INDEX` — child sitemap list (matches cardora.ca index)
- `SITE_PAGES` — static page paths
- `SITE_POSTS` — blog post paths
- `INVENTORY_SITEMAP_API` — live inventory sitemap API URL
- `PRODUCTION_HOST` — default host when headers are unavailable

### 5. Optional redirects

Copy redirects from `examples/redirects.ts` into your `next.config.ts` so sitemap URLs resolve on your site.

### 6. robots.txt

Add to `public/robots.txt`:

```
Sitemap: /sitemap.xml
```

## Endpoints

| URL | Description |
|-----|-------------|
| `/sitemap.xml` | Sitemap index |
| `/sitemap-posttype-page.xml` | Static pages |
| `/sitemap-posttype-post.2026.xml` | Blog posts |
| `/website/sitemap` | Inventory (proxied from API) |
| `/sitemap.xsl` | Browser stylesheet |
| `/site-map/` | Redirects to `/sitemap.xml` |

## Notes

- No WordPress generator text in the XML or XSL.
- `/website/sitemap` rewrites `cardora.ca` URLs to your current domain automatically.
- Works on localhost and production (uses request host + protocol).
