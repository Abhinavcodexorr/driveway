export type SitemapIndexItem = {
  path: string;
  lastmod?: string;
};

/** Default production host when request headers are unavailable */
export const PRODUCTION_HOST = 'www.cardora.ca';

/** Matches https://www.cardora.ca/sitemap.xml */
export const SITEMAP_INDEX: SitemapIndexItem[] = [
  {
    path: '/sitemap-posttype-post.2026.xml',
    lastmod: '2026-03-27T09:02:13+00:00',
  },
  {
    path: '/sitemap-posttype-page.xml',
    lastmod: '2026-06-03T13:37:25+00:00',
  },
  {
    path: '/website/sitemap',
  },
];

/** Matches https://www.cardora.ca/sitemap-posttype-page.xml */
export const SITE_PAGES = [
  '/service/wheel-alignment/',
  '/service/tire-service/',
  '/service/brake-repair/',
  '/service/oil-change/',
  '/used-car-financing/',
  '/skip-the-dealership/',
  '/thank-you-trade-in/',
  '/schedule-an-appointment-with-expert/',
  '/trade-in-my-car/vehicle/',
  '/trade-in-my-car/vin/',
  '/thank-you-finance/',
  '/service/',
  '/contact-us/',
  '/protection-plans/',
  '/finance/',
  '/financing/',
  '/trade-in-my-car/',
  '/inventory/',
  '/thank-you/complete-verification/',
  '/thank-you/appointment/',
  '/thank-you/info/',
  '/blog/',
  '/payment-calculator/',
  '/',
  '/about-us/',
  '/thank-you/',
  '/site-map/',
  '/privacy-policy/',
  '/terms-conditions/',
  '/book-an-appointment/',
];

/** Matches https://www.cardora.ca/sitemap-posttype-post.2026.xml */
export const SITE_POSTS = [
  '/how-inflation-affects-the-used-suv-market/',
  '/leasing-vs-buying-a-new-car/',
];

/** Live inventory sitemap API — URLs are rewritten to your domain */
export const INVENTORY_SITEMAP_API =
  'https://cardora.zopsoftware.com/api/website/sitemap';

/** Hostnames replaced when proxying inventory sitemap */
export const INVENTORY_HOST_REWRITES = [
  'https://www.cardora.ca',
  'https://cardora.ca',
] as const;
