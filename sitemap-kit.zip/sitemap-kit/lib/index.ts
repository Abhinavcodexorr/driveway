export {
  SITEMAP_INDEX,
  SITE_PAGES,
  SITE_POSTS,
  INVENTORY_SITEMAP_API,
  INVENTORY_HOST_REWRITES,
  PRODUCTION_HOST,
} from './config';
export { getSitemapBaseUrl } from './getBaseUrl';
export {
  xmlResponse,
  buildIndexXml,
  buildUrlsetXml,
  buildPostsXml,
} from './xml';
export {
  GET_SITEMAP_INDEX,
  GET_SITEMAP_PAGES,
  GET_SITEMAP_POSTS,
  GET_WEBSITE_SITEMAP,
  GET_SITEMAP_XSL,
  SITEMAP_DIR,
} from './handlers';
