<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
	xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
	xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
	<xsl:template match="/">
		<html xmlns="http://www.w3.org/1999/xhtml">
			<head>
				<title>
					<xsl:choose>
						<xsl:when test="sitemap:sitemapindex">XML Sitemap — Index</xsl:when>
						<xsl:otherwise>XML Sitemap</xsl:otherwise>
					</xsl:choose>
				</title>
				<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
				<style type="text/css">
					body{font-family:"Lucida Grande","Lucida Sans Unicode",Tahoma,Verdana,sans-serif;font-size:13px}
					#header{padding:2px;margin:10px;font-size:8pt;color:gray}
					a{color:black}
					td{font-size:11px}
					th{text-align:left;padding-right:30px;font-size:11px}
					tr.high{background-color:whitesmoke}
				</style>
			</head>
			<body>
				<h1>
					<xsl:choose>
						<xsl:when test="sitemap:sitemapindex">XML Sitemap — Index</xsl:when>
						<xsl:otherwise>XML Sitemap</xsl:otherwise>
					</xsl:choose>
				</h1>
				<div id="header">
					<p>
						This XML sitemap helps search engines discover pages on this site.
						<a href="https://www.sitemaps.org/">Learn more about XML sitemaps.</a>
					</p>
				</div>
				<div id="content">
					<xsl:choose>
						<xsl:when test="sitemap:sitemapindex">
							<table cellpadding="5">
								<tr class="high">
									<th>#</th>
									<th>XML Sitemap</th>
									<th>Last Modified</th>
								</tr>
								<xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
									<tr>
										<xsl:if test="position() mod 2 != 1">
											<xsl:attribute name="class">high</xsl:attribute>
										</xsl:if>
										<td><xsl:value-of select="position()"/></td>
										<td>
											<xsl:variable name="itemURL"><xsl:value-of select="sitemap:loc"/></xsl:variable>
											<a href="{$itemURL}"><xsl:value-of select="sitemap:loc"/></a>
										</td>
										<td>
											<xsl:if test="sitemap:lastmod != ''">
												<xsl:value-of select="concat(substring(sitemap:lastmod,1,10),' ',substring(sitemap:lastmod,12,8),' (',substring(sitemap:lastmod,20,6),')')"/>
											</xsl:if>
										</td>
									</tr>
								</xsl:for-each>
							</table>
						</xsl:when>
						<xsl:otherwise>
							<table cellpadding="5">
								<tr class="high">
									<th>#</th>
									<th>URL</th>
									<th># Images</th>
									<th>Last Modified</th>
								</tr>
								<xsl:for-each select="sitemap:urlset/sitemap:url">
									<tr>
										<xsl:if test="position() mod 2 != 1">
											<xsl:attribute name="class">high</xsl:attribute>
										</xsl:if>
										<td><xsl:value-of select="position()"/></td>
										<td>
											<xsl:variable name="itemURL"><xsl:value-of select="sitemap:loc"/></xsl:variable>
											<a href="{$itemURL}"><xsl:value-of select="sitemap:loc"/></a>
										</td>
										<td>
											<xsl:if test="count(image:image) &gt; 0">
												<xsl:value-of select="count(image:image)"/>
											</xsl:if>
										</td>
										<td>
											<xsl:if test="sitemap:lastmod != ''">
												<xsl:value-of select="concat(substring(sitemap:lastmod,1,10),' ',substring(sitemap:lastmod,12,8),' (',substring(sitemap:lastmod,20,6),')')"/>
											</xsl:if>
										</td>
									</tr>
								</xsl:for-each>
							</table>
						</xsl:otherwise>
					</xsl:choose>
				</div>
			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>
