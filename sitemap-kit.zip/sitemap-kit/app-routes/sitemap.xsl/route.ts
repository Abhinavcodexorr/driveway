import { GET_SITEMAP_XSL } from '@/sitemap/handlers';

export async function GET() {
  return GET_SITEMAP_XSL();
}
