import { GET_SITEMAP_PAGES } from '@/sitemap/handlers';

export async function GET() {
  return GET_SITEMAP_PAGES();
}
