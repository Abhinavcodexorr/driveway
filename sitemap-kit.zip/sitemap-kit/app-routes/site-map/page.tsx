import { redirect } from 'next/navigation';

export default function SiteMapPage() {
  redirect('/sitemap.xml');
}
