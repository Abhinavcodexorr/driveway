import { GET_SITEMAP_POSTS } from '@/sitemap/handlers';

export async function GET() {
  return GET_SITEMAP_POSTS();
}
