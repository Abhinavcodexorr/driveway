import { GET_WEBSITE_SITEMAP } from '@/sitemap/handlers';

export async function GET() {
  return GET_WEBSITE_SITEMAP();
}
