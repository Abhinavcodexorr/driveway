import { GET_SITEMAP_INDEX } from '@/sitemap/handlers';

export async function GET() {
  return GET_SITEMAP_INDEX();
}
