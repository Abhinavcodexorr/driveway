/** Paste into next.config.ts → async redirects() */
export const sitemapRedirects = [
  {
    source: '/service/wheel-alignment',
    destination: '/service/wheel-service',
    permanent: true,
  },
  {
    source: '/service/wheel-alignment/',
    destination: '/service/wheel-service/',
    permanent: true,
  },
  {
    source: '/service/brake-repair',
    destination: '/service/brakes',
    permanent: true,
  },
  {
    source: '/service/brake-repair/',
    destination: '/service/brakes/',
    permanent: true,
  },
  {
    source: '/used-car-financing',
    destination: '/financing',
    permanent: true,
  },
  {
    source: '/used-car-financing/',
    destination: '/financing/',
    permanent: true,
  },
  {
    source: '/trade-in-my-car/vehicle',
    destination: '/trade-in-my-car',
    permanent: false,
  },
  {
    source: '/trade-in-my-car/vehicle/',
    destination: '/trade-in-my-car/',
    permanent: false,
  },
  {
    source: '/trade-in-my-car/vin',
    destination: '/trade-in-my-car',
    permanent: false,
  },
  {
    source: '/trade-in-my-car/vin/',
    destination: '/trade-in-my-car/',
    permanent: false,
  },
  {
    source: '/thank-you/appointment',
    destination: '/thank-you',
    permanent: false,
  },
  {
    source: '/thank-you/appointment/',
    destination: '/thank-you/',
    permanent: false,
  },
  {
    source: '/thank-you/info',
    destination: '/thank-you',
    permanent: false,
  },
  {
    source: '/thank-you/info/',
    destination: '/thank-you/',
    permanent: false,
  },
  {
    source: '/blog',
    destination: '/',
    permanent: false,
  },
  {
    source: '/blog/',
    destination: '/',
    permanent: false,
  },
  {
    source: '/how-inflation-affects-the-used-suv-market',
    destination: '/',
    permanent: false,
  },
  {
    source: '/how-inflation-affects-the-used-suv-market/',
    destination: '/',
    permanent: false,
  },
  {
    source: '/leasing-vs-buying-a-new-car',
    destination: '/',
    permanent: false,
  },
  {
    source: '/leasing-vs-buying-a-new-car/',
    destination: '/',
    permanent: false,
  },
];
